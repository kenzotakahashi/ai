To run a program:

1. Type python3 hw.py or open the file in IDLE and run it.
2. Type 9 characters in either lowercase or uppercase.
3. Choose algorithm. If you want to use breadth first search, just hit Enter.
If you want to use iterative deepening search, hit i and then Enter.
